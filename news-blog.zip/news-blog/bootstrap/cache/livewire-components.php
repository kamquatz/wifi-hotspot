<?php return array (
  'categories.categories' => 'App\\Http\\Livewire\\Categories\\Categories',
  'categories.categoryposts' => 'App\\Http\\Livewire\\Categories\\Categoryposts',
  'posts.post' => 'App\\Http\\Livewire\\Posts\\Post',
  'posts.posts' => 'App\\Http\\Livewire\\Posts\\Posts',
  'tags.tagposts' => 'App\\Http\\Livewire\\Tags\\Tagposts',
  'tags.tags' => 'App\\Http\\Livewire\\Tags\\Tags',
);